
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Login</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <link rel="stylesheet" href=".style-eco.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>

<body>
    
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Home</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp 5 CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>
    <!-- Home Page Start -->

    <!--  Preloader Start  -->

    <!-- Header Start -->
    <?php
        include "./option.php";
    ?>
    <!-- Header End -->

        <!-- Tab And Mobile View -->
        <div class="collapse navbar-collapse odas_mobile_view" id="navbarSupportedContent">
            <div class="show_width container">
                <div class="text-right">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation"> <span><i class="fa fa-bars"></i></span></button>
                </div>
                
                <div class="navbar px-0 odas_mobile_view_body"></div>
            </div>
        </div>
        <!-- Tab And Mobile View -->
    </header>
    <!-- header End -->

        <?php
			$db =  mysqli_connect("127.0.0.1", "root" , "", "transittracktest");
			if ($db->connect_error) {
				echo "Something wrong with datababse connection";
			}
			else{
				$sql = "SELECT * FROM list";
				$result = $db->query($sql);
				$db->close();
			} 
		?>
        
    <!-- Bus Location Section Start -->
    <section class="trtr_about_hero position-relative">
        <div class="container">
            <div class="trtr_about_us_title_wrapper text-center">
                <h1>Bus Location</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Bus Location</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- Bus Location Section End -->     
	<!-- About Booking Section Start -->

	<section class="trtr_about_booking_wrapper">
        <div class="container">
            <div class="row">
                
                    <div class="trtr_booking_wrapper position-relative">
					<div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                            <tr>
                                <th style="width: 40px;">ID</th>
                                <th style="width: 120px;">Checker Name</th>
                                <th style="width: 120px;">Bus Name</th>
                                <th style="width: 50px;">Avaiable Seat</th>
                                <th style="width: 120px;">Bus Number</th>
                                <th style="width: 150px;">Bus Stopage</th>
                                <th style="width: 150px;">Time and Date</th>
                                
                            </tr>
                        </thead>
                        <tbody>

							<?php
								if ($result->num_rows > 0) {
									$count = 1;
									while ($row = $result->fetch_assoc()) {
										echo '<tr>';
										echo '<td>' . $count . '</td>';
                                        echo '<td>' . $row["user_name"] . '</td>';
										echo '<td>' . $row["bus_name"] . '</td>';
										echo '<td>' . $row["available_seat"] . '</td>';
										echo '<td>' . $row["bus_number"] . '</td>';
										echo '<td>' . $row["location"] . '</td>';
										echo '<td>' . $row["datetime"] . '</td>';;
										echo '</tr>';
										$count++;
									}
								} else {
									echo '<tr><td colspan="6">No records found</td></tr>';
								}
							?>


                        </tbody>
                    </table>
               
                    </div>
                </div>
            </div>
        </div>
    </section>

       
    <!-- Footer Section Start -->
    <footer class="trtr_footer_wrapper">
        <div class="trtr_overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-xl-3 mb-4 mb-md-0">
                        <a href="./index.php"><img src="./assets/images/footer_logo.svg" alt="Footer Logo"></a>
                        <p>It is a long established fact that a reader will be distracted lookings.</p>
                        <ul class="list-group list-group-horizontal trtr_social_media">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="trtr_page_link">
                            <h5>Useful Links</h5>
                            <ul class="trtr_useful_link">
                                <li>
                                    <a href="./pages/about_us.php">About Us</a>
                                </li>
                                <li>
                                    <a href="./pages/service.php">Service</a>
                                </li>
                                <li>
                                    <a href="./pages/gallery.php">Gallery</a>
                                </li>
                               
                                <li>
                                    <a href="./pages/contactus.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-xl-3">
                        <h5>Contact</h5>
                        <ul class="trtr_footer_contact">
                            <li>
                                <a href="tel:+13866883295" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                    </div>
                                    +1 386-688-3295
                                </a>
                            </li>
                            <li>
                                <a href="mailto:contact@TransitTrack.com" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                    </div>
                                    contact@TransitTrack.com
                                </a>
                            </li>
                            <li>
                                <a href="https://www.google.com/maps/place/GXF4%2B8HQ,+Chippenham,+UK/@51.5233408,-2.0460905,17z/data=!3m1!4b1!4m5!3m4!1s0x4871630088ddd45d:0x560ecf1533aac5e1!8m2!3d51.5233375!4d-2.0435156?entry=ttu" target="_blank" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    GXF4+8HQ Chippenham United Kingdom
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="trtr_copy_right">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                            <p class="mb-0">Copyright &copy; <a href="#" target="_blank">TransitTrack</a>. All Right Reserved</p>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                            <a href="#" target="_blank">Terms & Conditions</a>
                            <a href="#" target="_blank" class="ps-4">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->
    
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    <!-- Home Page End -->
    
    

    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>