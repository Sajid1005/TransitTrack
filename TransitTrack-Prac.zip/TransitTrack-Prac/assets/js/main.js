
    // Counter JS
    var isAlreadyRun = false;

    $(window).scroll( function(){
        function counter() {
            $('.odas_counter').each( function(i){

                var bottom_of_object = $(this).position().top + $(this).outerHeight() / 2;
                var bottom_of_window = $(window).scrollTop() + $(window).height();

                if( bottom_of_window > ( bottom_of_object + 20 )  ){
                    if (!isAlreadyRun) {
                        $('.count').each(function () {
                        
                        $(this).prop('Counter', 0).animate({
                            Counter: $(this).text()
                        }, {
                                duration: 3500,
                                easing: 'swing',
                                step: function (now) {
                                    $(this).text(Math.ceil(now));
                                }
                            });
                        });
                    }
                    isAlreadyRun = true;
                }
            }); 
        }counter();
    });


    
    
    $(window).on("load",function(){
        //Count UP
        
        

        // Navbar Toggol Icon
        function navbar_toggler(){
            $('.navbar-toggler[data-toggle=collapse]').click(function () {
                if( $(".navbar-toggler[data-toggle=collapse] i").hasClass('fa-bars') ) {

                    $(".navbar-toggler[data-toggle=collapse] i").removeClass("fa-bars");
                    $(".navbar-toggler[data-toggle=collapse] i").addClass("fa-times");
                }
                else {      
                    $(".navbar-toggler[data-toggle=collapse] i").removeClass("fa-times");
                    $(".navbar-toggler[data-toggle=collapse] i").addClass("fa-bars");
                }
            });
        }
        navbar_toggler();
        
        // Navbar Clone In Mobile Device
        function navClone(){
            $('.js-clone-nav').each(function(){
                var $this = $(this);
                $this.clone().attr('class', 'navbar-nav ml-auto').appendTo('.odas_mobile_view_body');
            });
        }
        navClone();

        // Silk Carousel slick
        function slickCarousel() {
            $('.odas_testimonial_slider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: true,
                arrows: false,
                autoplaySpeed: 2000,
                dots: true,
                infinite: true,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });

            // home version two testimonial
            $('.odas_testimonial_slider_2').slick({
                slidesToShow: 2,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                dots: false,
                infinite: true,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        arrows: false
                      }
                    }
                ]
            });

            // Coming soon page image carousel
            $('.odas_coming_soon_carousel').slick({
                slidesToShow: 4,
                slidesToScroll: 1,
                autoplay: true,
                autoplaySpeed: 2000,
                dots: true,
                infinite: true,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                ]
            });

            $('.odas_about_slider').slick({
                slidesToShow: 2,
                slidesToScroll: 1,
                autoplay: true,
                arrows: false,
                autoplaySpeed: 2000,
                dots: true,
                infinite: true,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1,
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 2,
                        slidesToScroll: 1
                      }
                    }
                ]
            });

            $('.odas_moment_slider').slick({
                slidesToShow: 1,
                slidesToScroll: 1,
                autoplay: false,
                arrows: false,
                autoplaySpeed: 2000,
                dots: true,
                infinite: true,
                responsive: [
                    {
                      breakpoint: 1024,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1,
                      }
                    },
                    {
                      breakpoint: 767,
                      settings: {
                        slidesToShow: 1,
                        slidesToScroll: 1
                      }
                    }
                  ]
            });
        }
        slickCarousel();

        // Department page Load More Button
        function department_load_more() {
            $(".odas_department_column").slice(0, 6).show();

            if( $(".odas_department_column:hidden").length != 0 ) {
                $("#odas_department_load_more").css("display","block");
                
                $("#odas_department_load_more").on("click", function(e){
                    e.preventDefault();
                    $(".odas_department_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_department_column:hidden").length == 0) {
                        $("#odas_department_load_more").css("display","none");
                    }
                });
            }
        }
        department_load_more();

        // Services page Load More Button
        function Services_load_more() {
            $(".odas_services_column").slice(0, 6).show();

            if( $(".odas_services_column:hidden").length != 0 ) {
                $("#odas_services_load_more").css("display","block");
                
                $("#odas_services_load_more").on("click", function(e){
                    e.preventDefault();
                    $(".odas_services_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_services_column:hidden").length == 0) {
                        $("#odas_services_load_more").css("display","none");
                    }
                });
            }
        }
        Services_load_more();

        // blog v2 page latest blog Load More Button
        function latest_blog_loadmore() {
            $(".odas_latest_blog_column").slice(0, 6).show();

            if( $(".odas_latest_blog_column:hidden").length != 0 ) {
                $("#odas_blog_v2_loadmore_1").css("display","block");
                
                $("#odas_blog_v2_loadmore_1").on("click", function(e){
                    e.preventDefault();
                    $(".odas_latest_blog_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_latest_blog_column:hidden").length == 0) {
                        $("#odas_blog_v2_loadmore_1").css("display","none");
                    }
                });
            }
        }
        latest_blog_loadmore();

        // blog v2 page popular blog Load More Button
        function popular_blog_loadmore() {
            $(".odas_popular_blog_column").slice(0, 6).show();

            if( $(".odas_popular_blog_column:hidden").length != 0 ) {
                $("#odas_blog_v2_loadmore_2").css("display","block");
                
                $("#odas_blog_v2_loadmore_2").on("click", function(e){
                    e.preventDefault();
                    $(".odas_popular_blog_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_popular_blog_column:hidden").length == 0) {
                        $("#odas_blog_v2_loadmore_2").css("display","none");
                    }
                });
            }
        }
        popular_blog_loadmore();

        // blog v2 page weekly blog Load More Button
        function weekly_blog_loadmore() {
            $(".odas_weekly_blog_column").slice(0, 6).show();

            if( $(".odas_weekly_blog_column:hidden").length != 0 ) {
                $("#odas_blog_v2_loadmore_3").css("display","block");
                
                $("#odas_blog_v2_loadmore_3").on("click", function(e){
                    e.preventDefault();
                    $(".odas_weekly_blog_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_weekly_blog_column:hidden").length == 0) {
                        $("#odas_blog_v2_loadmore_3").css("display","none");
                    }
                });
            }
        }
        weekly_blog_loadmore();

        // archive page blog archive Load More Button
        function blog_archive_loadmore() {
            $(".odas_blog_archive_column").slice(0, 6).show();

            if( $(".odas_blog_archive_column:hidden").length != 0 ) {
                $("#odas_blog_archive_loadmore").css("display","block");
                
                $("#odas_blog_archive_loadmore").on("click", function(e){
                    e.preventDefault();
                    $(".odas_blog_archive_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_blog_archive_column:hidden").length == 0) {
                        $("#odas_blog_archive_loadmore").css("display","none");
                    }
                });
            }
        }
        blog_archive_loadmore();

        // archive page popular blog Load More Button
        function popular_post_archive() {
            $(".odas_popular_archive_column").slice(0, 6).show();

            if( $(".odas_popular_archive_column:hidden").length != 0 ) {
                $("#odas_popular_archive_loadmore").css("display","block");
                
                $("#odas_popular_archive_loadmore").on("click", function(e){
                    e.preventDefault();
                    $(".odas_popular_archive_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_popular_archive_column:hidden").length == 0) {
                        $("#odas_popular_archive_loadmore").css("display","none");
                    }
                });
            }
        }
        popular_post_archive();

        // archive page weekly blog Load More Button
        function weekly_post_archive() {
            $(".odas_weekly_archive_column").slice(0, 6).show();

            if( $(".odas_weekly_archive_column:hidden").length != 0 ) {
                $("#odas_weekly_archive_loadmore").css("display","block");
                
                $("#odas_weekly_archive_loadmore").on("click", function(e){
                    e.preventDefault();
                    $(".odas_weekly_archive_column:hidden").slice(0, 3).slideDown(500);
                    if($(".odas_weekly_archive_column:hidden").length == 0) {
                        $("#odas_weekly_archive_loadmore").css("display","none");
                    }
                });
            }
        }
        weekly_post_archive();

    

        // Gallery FancyBox Js
        function fancybox() {
            $('[data-fancybox]').fancybox({
                protect: true,
                buttons: [
                    "fullScreen",
                    "thumbs",
                    "share",
                    "slideShow",
                    "close"
                ],
                image: {
                    preload: false
                },
            });
        }
        fancybox();

        function shuffleJs() {
            if ($('.shuffle-wrapper').length !== 0) {
                var Shuffle = window.Shuffle;
                var myShuffle = new Shuffle(document.querySelector('.shuffle-wrapper'), {
                    itemSelector: '.shuffle-item',
                    sizer: '.shuffle-sizer',
                    buffer: 1,
                });
                $('input[name="shuffle-filter"]').on('change', function (evt) {
                    var input = evt.currentTarget;
                    if (input.checked) {
                        myShuffle.filter(input.value);
                    }
                });
                $('.shuffle-btn-group label').on('click', function () {
                    $('.shuffle-btn-group label').removeClass('active');
                    $(this).addClass('active');
                });
            }
        }
        shuffleJs();
        
        // Excerpt
        var odas_service_text_excerpt = $('.odas_services_card ').find('.card').find('.card-text');
        var odas_blog_title_excerpt = $('.odas_blog_card ').find('.card').find('.card-title');
        var odas_blog_title_excerpt_sm = $('.odas_blog_card_sm').find('.card').find('.card-title');
        function excerpt(excerptElement, number , more = "..."){
            excerptElement.each(function(){
            var productTitle = $(this).text(),
            productTitleExcerpt,
            toArray = productTitle.split("", number),
            joinArray = toArray.join(''),
            joinArrayToArray = joinArray.split(" "),
            joinArrayToArrayPop = joinArrayToArray.pop(),
            joinArrayToArrayPopPush = joinArrayToArray.push(more),
            joinArrayToArrayPopPushJoin = joinArrayToArray.join(' '),
            productTitleExcerpt = joinArrayToArrayPopPushJoin;

            if(productTitle.length > number){
                productTitle = productTitleExcerpt;
                $(this).text(productTitle);
            }
            });
        }
        excerpt(odas_service_text_excerpt, 35, "");
        excerpt(odas_blog_title_excerpt, 80, "");
        excerpt(odas_blog_title_excerpt_sm, 45, "");
    
        // Load More BUtton
        function load_more($sectionName = "", $locationCol, $btnId , $defaultShow = 6, $sliceShow = 2 ) {
            $($locationCol).css("display","none");

            $($locationCol).slice(0, $defaultShow).fadeIn();
            if( $($locationCol+':hidden').length != 0 ) {
                $($sectionName+" "+'.odas_viewmore_btn').fadeIn();
                
                $($btnId).on("click", function(e){
                    e.preventDefault();

                    $($locationCol+':hidden').slice(0, $sliceShow).slideDown(500);
                    if($($locationCol+':hidden').length == 0) {
                        $($sectionName+" "+'.odas_viewmore_btn').fadeOut();
                    }
                });
            }
        }
        load_more(".odas_service", ".odas_services_column", "#service_load_more", 6, 3);

        // Code Verification
        function verification_code(){
            const inputElements = [...document.querySelectorAll('input.code-input')]
            inputElements.forEach((ele,index)=>{
                ele.addEventListener('keydown',(e)=>{
                    if(e.keyCode === 8 && e.target.value==='') inputElements[Math.max(0,index-1)].focus()
                })
                ele.addEventListener('input',(e)=>{
                    const [first,...rest] = e.target.value
                    e.target.value = first ?? ''
                    const lastInputBox = index===inputElements.length-1
                    const insertedContent = first!==undefined
                    if(insertedContent && !lastInputBox) {
                        inputElements[index+1].focus()
                        inputElements[index+1].value = rest.join('')
                        inputElements[index+1].dispatchEvent(new Event('input'))
                    }
                })
            });

            function onSubmit(e){
                e.preventDefault()
                const code = [...document.getElementsByTagName('input')]
                    .filter(({name})=>name)
                    .map(({value})=>value)
                    .join('')
                console.log(code)
            }
        }verification_code();

        //DatePiker
        $( function() {
            $( "#odas_date_picker" ).datepicker();
        });
    });
    
    // wow Init
    new WOW().init();    

   

// Form Validation js
(function() {
    'use strict';
    window.addEventListener('load', function() {
        var forms = document.getElementsByClassName('form_validation');
        var validation = Array.prototype.filter.call(forms, function(form) {
          form.addEventListener('submit', function(event) {
            if (form.checkValidity() === false) {
              event.preventDefault();
              event.stopPropagation();
            }
            form.classList.add('was-validated');
          }, false);
        });
    }, false);
})();

// /* Template Name: Arisrtoaid-Bootstrap Medical Service Template
// Template URI: https://www.designtocodes.com/product/arisrtoaid-bootstrap-medical-service-template
// Description: Arisrtoaid is a fully responsive medical service website template inspired by a modern flat design.
// Author: DesignToCodes
// Author URI: https://www.designtocodes.com
// Text Domain: Arisrtoaid */
