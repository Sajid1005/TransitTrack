
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Gallery</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>

    <!-- Header Start -->
    <?php
        include "./option.php";
    ?>
    <!-- Header End -->

    <!-- Contact Page Start -->

    <!-- Contact Hero Section Start -->
    <section class="trtr_contact_hero position-relative">
        <div class="container">
            <div class="trtr_about_us_title_wrapper text-center">
                <h1>Contact Us</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Contact</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- Contact Hero Section End -->

    <!-- Contact section Start -->
    <section class="trtr_contact_wrapper trtr_contact_page">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-4 mb-5 mb-lg-0">
                    <div class="trtr_contact_us_wrapper">
                        <h2>Get in touch</h2>
                        <p class="trtr_title_content">Need a consultation for your room?</p>
                        <ul class="trtr_contact_media">
                            <li class="d-flex">
                                <i class="fas fa-phone-alt"></i>
                                <div class="trtr_contact_info">
                                    <p class="mb-1"><span>Emergency Help</span></p>
                                    <h6>+1 386-688-3295</h6>
                                </div>
                            </li>
                            <li class="d-flex">
                                <i class="fas fa-envelope"></i>
                                <div class="trtr_contact_info">
                                    <p class="mb-1"><span>Quick Email</span></p>
                                    <h6>contact@TransitTrack.com</h6>
                                </div>
                            </li>
                            <li class="d-flex">
                                <i class="fas fa-map-marker-alt"></i>
                                <div class="trtr_contact_info">
                                    <p class="mb-1"><span>Office Address</span></p>
                                    <h6>GXF4+8HQ Chippenham United Kingdom</h6>
                                </div>
                            </li>
                        </ul>
                        <ul class="list-group list-group-horizontal trtr_social_media">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="col-md-12 col-lg-8 mb-5 mb-lg-0">
                    <div class="trtr_form_wrapper">
                        <h2 class="mb-4">Send Message</h2>
                        <form class="row needs-validation" novalidate>
                            <div class="col-md-6">
                                <label for="validationCustomFirstName" class="form-label mb-2 mb-md-3">First Name</label>
                                <input type="text" class="form-control" id="validationCustomFirstName" autocomplete="off" placeholder="Enter your first name" required>
                            </div>
                            <div class="col-md-6">
                                <label for="validationCustomLastName" class="form-label mb-2 mb-md-3">Last Name</label>
                                <input type="text" class="form-control" id="validationCustomLastName" autocomplete="off" placeholder="Enter your last name" required>
                            </div>
                            <div class="col-md-6">
                                <label for="validationCustomEmail" class="form-label mb-2 mb-md-3">Email Address</label>
                                <div class="input-group has-validation">
                                    <input type="email" class="form-control" id="validationCustomEmail" autocomplete="on" placeholder="Enter your email address" required>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <label for="validationCustomLastNumber" class="form-label mb-2 mb-md-3">Phone Number</label>
                                <input type="number" class="form-control" id="validationCustomLastNumber" autocomplete="off" placeholder="Last Name" required>
                            </div>
                            <div class="col-md-12">
                                <label for="validationCustomMessage" class="form-label mb-2 mb-md-3">Message</label>
                                <textarea class="form-control" rows="7" id="validationCustomMessage" placeholder="Type message here.." required></textarea>
                                <button class="btn" type="submit">Send Message</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="trtr_contact_map position-relative rounded-3">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d6050.469896764953!2d-73.98371524427581!3d40.69082292666655!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c25a4b350fc303%3A0x4ae5d65964e327f0!2sWilloughby%20St%2C%20Brooklyn%2C%20NY%2011201%2C%20USA!5e0!3m2!1sen!2sbd!4v1708337743218!5m2!1sen!2sbd" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>
    <!-- Contact section End -->
    

    <!-- Footer Section Start -->
    <footer class="trtr_footer_wrapper">
        <div class="trtr_overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-xl-3 mb-4 mb-md-0">
                        <a href="./index.php"><img src="./assets/images/footer_logo.svg" alt="Footer Logo"></a>
                        <p>It is a long established fact that a reader will be distracted lookings.</p>
                        <ul class="list-group list-group-horizontal trtr_social_media">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="trtr_page_link">
                            <h5>Useful Links</h5>
                            <ul class="trtr_useful_link">
                                <li>
                                    <a href="./about_us.php">About Us</a>
                                </li>
                                <li>
                                    <a href="./service.php">Service</a>
                                </li>
                                <li>
                                    <a href="./gallery.php">Gallery</a>
                                </li>
                               
                                <li>
                                    <a href="./contactus.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-xl-3">
                        <h5>Contact</h5>
                        <ul class="trtr_footer_contact">
                            <li>
                                <a href="tel:+13866883295" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                    </div>
                                    +1 386-688-3295
                                </a>
                            </li>
                            <li>
                                <a href="mailto:contact@TransitTrack.com" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                    </div>
                                    contact@TransitTrack.com
                                </a>
                            </li>
                            <li>
                                <a href="https://www.google.com/maps/place/GXF4%2B8HQ,+Chippenham,+UK/@51.5233408,-2.0460905,17z/data=!3m1!4b1!4m5!3m4!1s0x4871630088ddd45d:0x560ecf1533aac5e1!8m2!3d51.5233375!4d-2.0435156?entry=ttu" target="_blank" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    GXF4+8HQ Chippenham United Kingdom
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="trtr_copy_right">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                            <p class="mb-0">Copyright &copy; <a href="#" target="_blank">TransitTrack</a>. All Right Reserved</p>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                            <a href="#" target="_blank">Terms & Conditions</a>
                            <a href="#" target="_blank" class="ps-4">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->
        
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>
