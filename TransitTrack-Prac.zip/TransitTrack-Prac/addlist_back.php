<?php
    $busname = $_POST["busname"]; 
    $busstopage = $_POST["busstopage"]; 
	$seatavailable = $_POST["seatavailable"];	


    $db =  mysqli_connect("127.0.0.1", "root" , "", "transittracktest");
	
	if ($db->connect_error) {
         echo "Something wrong with datababse connection";
     }
	 else{
		 echo "Succesfull";
	 }
	 
	 $x = "INSERT INTO bus (busname, busstopage, seatavailable ) VALUES ('$busname', '$busstopage', '$seatavailable')";
	 
	 $db->query($x);
	 header("Location:./index.php"); 
?>