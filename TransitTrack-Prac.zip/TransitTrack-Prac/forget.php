
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Gallery</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>

    <!-- Login Section Start -->
    <section class="trtr_forget_password_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="trtr_login">
                        <h2 class="text-center">Reset password</h2>
                        <div class="trtr_validation_wrapper">
                            <form class="row needs-validation align-items-center" novalidate>
                                <div class="col-md-12 mb-4">
                                    <label for="validationCustomEmail" class="form-label mb-3">Email Address</label>
                                    <div class="input-group has-validation">
                                        <input type="email" class="form-control" id="validationCustomEmail" autocomplete="on" placeholder="Enter your email" required>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn w-100 mt-0 mt-xl-3" type="submit">reset</button>
                                </div>
                            </form>
                            <a href="./login.php">back to login</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Login Section End -->
        
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>

