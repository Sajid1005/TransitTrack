
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Home</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp 5 CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- <link rel="stylesheet" href="./style-eco.css"> -->
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>
    
    <?php
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $user_name = $_POST["user_name"];
            $bus_name = $_POST["bus_name"]; 
            $available_seat = $_POST["available_seat"];
            $bus_number = $_POST["bus_number"];
            $datetime = date('Y-m-d H:i:s');
            $location = $_POST['location']; // You need to have the location input in your form

            $db =  mysqli_connect("127.0.0.1", "root" , "", "transittracktest");
        
            if ($db->connect_error) {
                echo "Something wrong with database connection";
            } 
            $x = "INSERT INTO list (user_name,bus_name, available_seat, bus_number, datetime, location) VALUES ('$user_name','$bus_name', '$available_seat','$bus_number', '$datetime', '$location')";
            $db->query($x);
            $_SESSION['success'] = "Product Added Successfully";
            header("Location:./Project.php"); 
        }
    ?>


    <!-- Home Page Start -->

    <!--  Preloader Start  -->

    <!-- Header Start -->
    <?php
        include "./option.php";
    ?>
    <!-- Login Section Start -->
   
    <section class="trtr_login_wrapper">
        
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                <?php if(isset($_SESSION['success'])) {?>
                <p class="alert alert-primary"  ><?php echo $_SESSION['success']; ?></p>
                <?php unset($_SESSION['success']); } ?>
                    <div class="trtr_login">
                        <h2 class="text-center">Welcome Back</h2>
                        <div class="trtr_validation_wrapper">
                        <form class="row needs-validation align-items-center" method="POST" action="./addlist.php" enctype="multipart/form-data">
                            <div class="col-md-6 mb-4">
                                <label for="exampleFormControlFile1" class="form-label mb-3">Enter User Name</label>
                                <input name="user_name" type="text" class="form-control" autocomplete="off" placeholder="Enter user name" required>
                            </div>
                        
                            <div class="col-md-6 mb-4">
                                <label for="exampleFormControlFile1" class="form-label mb-3">Enter Bus Name</label>
                                <select name="bus_name" class="form-control" required>
                                    <option value="">Select Bus Name</option>
                                    <option value="Bus 1">Bus 1</option>
                                    <option value="Bus 2">Bus 2</option>
                                    <option value="Bus 1">Bus 3</option>
                                    <option value="Bus 2">Bus 4</option>
                                    <option value="Bus 1">Bus 5</option>
                                    <option value="Bus 2">Bus 6</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label for="exampleFormControlFile1" class="form-label mb-3">Enter Avaiable Seat</label>
                                <input name="available_seat" type="number" class="form-control" autocomplete="off" placeholder="Enter avaiable seat" required>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label for="exampleFormControlFile1" class="form-label mb-3">Enter Bus Number</label>
                                <input name="bus_number" type="text" class="form-control" autocomplete="off" placeholder="Enter bus number" required>
                            </div>

                            <div class="col-md-6 mb-4">
                                <label for="location" class="form-label mb-3">Enter Location</label>
                                <select name="location" class="form-control" id="location" required>
                                    <option value="">Select Location</option>
                                    <option value="Location 1">Location 1</option>
                                    <option value="Location 2">Location 2</option>
                                    <option value="Location 1">Location 3</option>
                                    <option value="Location 2">Location 4</option>
                                    <option value="Location 1">Location 5</option>
                                    <option value="Location 2">Location 6</option>
                                </select>
                            </div>
                            <div class="col-md-6 mb-4">
                                <label for="datetime" class="form-label mb-3">Enter Date and Time</label>
                                <?php
                                date_default_timezone_set('Asia/Dhaka');
                                $bangladesh_time = date('Y-m-d H:i:s');
                                ?>
                                <input type="text" class="form-control" value="<?php echo $bangladesh_time; ?>" disabled> 
                            </div>
                            <div class="col-md-12">
                                <button class="btn w-100 mt-0 mt-xl-3" type="submit">Add Product</button>
                            </div>
                        </form>


                        </div>
                       
                        
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Login Section End -->
    z
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>


