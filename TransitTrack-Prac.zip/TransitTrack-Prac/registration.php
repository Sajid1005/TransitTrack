
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Registration</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>
    <!-- Header Start -->
    
    <!-- Header End -->

    <!-- Registration Section Start -->
    <section class="trtr_registration_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2">
                    <div class="trtr_login">
                        <h2 class="text-center">Create an account</h2>
                        <p class="text-center trtr_title_content">Already have an account? <a href="./login.php">Login</a></p>
                        <div class="trtr_validation_wrapper">
                            <form class="row needs-validation align-items-center" method="post" action="./adduser.php">
                            
                                <div class="col-md-6 mb-4">
                                    <label for="firstname" class="form-label mb-3">First Name</label>
                                    <input class="form-control" type="text" id="firstname" autocomplete="off" name="firstname" placeholder="Enter your first name" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="lastname" class="form-label mb-3">Last Name</label>
                                    <input class="form-control" type="text" name ="lastname" id="lastname" autocomplete="off" placeholder="Enter your last name" required>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="email" class="form-label mb-3">Email Address</label>
                                    <div class="input-group has-validation">
                                        <input class="form-control" type="email" name= "email" id="email" autocomplete="off" placeholder="Enter your email" required>
                                    </div>
                                </div>
                                <div class="col-md-6 mb-4">
                                    <label for="password" class="form-label mb-3">Password</label>
                                    <div class="input-group has-validation">
                                        <input class="form-control" type="password" name="password"id="password" autocomplete="off" placeholder="Enter your password" required>
                                    </div>
                                </div>
                                
                                <div class="col-md-12">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="validationFormCheck" required>
                                        <p>I accept the <a href="#" target="_blank">Terms of Use</a></p>
                                    </div>
                                </div>
                                <div class="col-md-12">
                                    <button class="btn w-100 mt-3" type="submit">Signup</button>
                                </div>
                            </form>
                        </div>
                        <p class="trtr_divider position-relative text-center">Or</p>
                        <div class="d-flex flex-column flex-md-row justify-content-around">
                            <a href="#" class="btn trtr_company_btn mb-4 mb-md-0">
                                <i class="fab fa-google"></i>
                                Continue with Google
                            </a>
                            <a href="#" class="btn trtr_company_btn">
                                <i class="fab fa-apple"></i>
                                Sign In with Apple
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Login Section End -->
        
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>

