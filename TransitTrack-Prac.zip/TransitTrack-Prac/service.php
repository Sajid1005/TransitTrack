
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Gallery</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>
    <!-- Service Page Start -->


    <!-- Header Start -->
    <?php
        include "./option.php";
    ?>
    <!-- Header End -->

    <!-- Services Hero Section Start -->
    <section class="trtr_services_hero_wrapper position-relative">
        <div class="container">
            <div class="trtr_about_us_title_wrapper text-center">
                <h1>services</h1>
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="./index.php">Home</a></li>
                        <li class="breadcrumb-item active" aria-current="page">services</li>
                    </ol>
                </nav>
            </div>
        </div>
    </section>
    <!-- Services Hero Section End -->

    <!-- Services Details Section Start -->
    <section class="trtr_services_details">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">01</div>
                        <h4>Safety Inspections</h4>
                        <p>Sweep your loved one off their feet with a romantic retreat by the sea. Relax in a beautifully appointed oceanview suite, where champagne and chocolate.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">02</div>
                        <h4>Regulatory Compliance</h4>
                        <p>Fuel your body with nutritious meals and detoxifying juices, and take home a complimentary wellness gift basket. Daily yoga classes, meditation.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">03</div>
                        <h4>Documentation Review</h4>
                        <p>Embark on an adrenaline-fueled adventure by the ocean with our Adventure Package. Choose from a variety of thrilling activities,</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">04</div>
                        <h4>Auditing</h4>
                        <p>Enjoy hassle-free transportation with our pickup and drop-off service, ensuring smooth transition</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">05</div>
                        <h4>Training and Education</h4>
                        <p>Stay active and energized during your stay with access to our state-of-the-art fitness center, equipped</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">06</div>
                        <h4>Incident Investigation</h4>
                        <p>Travel light and worry-free with our convenient laundry services, ensuring your clothes stay fresh and clean</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5 mb-lg-0">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">07</div>
                        <h4>Risk Management</h4>
                        <p>Sweep your loved one off their feet with a romantic retreat by the sea. Relax in a beautifully appointed oceanview suite, where champagne and chocolate.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5 mb-lg-0">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">08</div>
                        <h4>Vehicle Inspections</h4>
                        <p>Fuel your body with nutritious meals and detoxifying juices, and take home a complimentary wellness gift basket. Daily yoga classes, meditation.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">09</div>
                        <h4>Load Verification</h4>
                        <p>Embark on an adrenaline-fueled adventure by the ocean with our Adventure Package. Choose from a variety of thrilling activities,</p>
                    </div>
                </div>
                <div class="trtr_service_btn">
                    <a href="#" id="trtr_service_more" class="btn secondary_btn mx-auto">
                        load more
                    </a>
                </div>
            </div>
        </div>
    </section>
    <!-- Services Details Section End -->

    <!-- Footer Section Start -->
    <footer class="trtr_footer_wrapper">
        <div class="trtr_overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-xl-3 mb-4 mb-md-0">
                        <a href="./index.php"><img src="./assets/images/footer_logo.svg" alt="Footer Logo"></a>
                        <p>It is a long established fact that a reader will be distracted lookings.</p>
                        <ul class="list-group list-group-horizontal trtr_social_media">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="trtr_page_link">
                            <h5>Useful Links</h5>
                            <ul class="trtr_useful_link">
                                <li>
                                    <a href="./about_us.php">About Us</a>
                                </li>
                                <li>
                                    <a href="./service.php">Service</a>
                                </li>
                                <li>
                                    <a href="./gallery.php">Gallery</a>
                                </li>
                              
                                <li>
                                    <a href="./contactus.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
      
                    <div class="col-md-6 col-xl-3">
                        <h5>Contact</h5>
                        <ul class="trtr_footer_contact">
                            <li>
                                <a href="tel:+13866883295" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                    </div>
                                    +1 386-688-3295
                                </a>
                            </li>
                            <li>
                                <a href="mailto:contact@TransitTrack.com" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                    </div>
                                    contact@TransitTrack.com
                                </a>
                            </li>
                            <li>
                                <a href="https://www.google.com/maps/place/GXF4%2B8HQ,+Chippenham,+UK/@51.5233408,-2.0460905,17z/data=!3m1!4b1!4m5!3m4!1s0x4871630088ddd45d:0x560ecf1533aac5e1!8m2!3d51.5233375!4d-2.0435156?entry=ttu" target="_blank" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    GXF4+8HQ Chippenham United Kingdom
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="trtr_copy_right">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                            <p class="mb-0">Copyright &copy; <a href="#" target="_blank">TransitTrack</a>. All Right Reserved</p>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                            <a href="#" target="_blank">Terms & Conditions</a>
                            <a href="#" target="_blank" class="ps-4">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->
    
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->

    <!-- Service Page Start -->
    
    


    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
    <!-- Js Start -->
    <script>
    // Load More and Explore More Button JS
        function updateSliceShow() {
            var windowWidth = $(window).width();
            var $defaultShow, $sliceShow;
        
            if (windowWidth < 768) {
            $defaultShow = 1;
            $sliceShow = 1;
            } else if (windowWidth < 992) {
            $defaultShow = 2;
            $sliceShow = 2;
            } else if (windowWidth < 1200) {
            $defaultShow = 6;
            $sliceShow = 3;
            } else {
            $defaultShow = 6;
            $sliceShow = 3;
            }
        
            return [$sliceShow, $defaultShow];
        }
        
        function load_more($sectionName = "", $locationCol, $btnParentClass ,$btnId, $defaultShow = 6, $sliceShow = 3) {
            $($locationCol).css("display", "none");
            $($sectionName + " " + $btnParentClass).css("display", "none");
        
            $($locationCol).slice(0, $defaultShow).fadeIn();
            if ($($locationCol + ":hidden").length != 0) {
            $($sectionName + " " + $btnParentClass).css("display", "flex");
        
            $($btnId).off("click").on("click", function (e) {
                e.preventDefault();
        
                $($locationCol + ":hidden").slice(0, $sliceShow).slideDown(500);
                if ($($locationCol + ":hidden").length == 0) {
                $($sectionName + " " + $btnParentClass).css("display", "none");
                }
            });
            }
        }
        
        $(document).ready(function () {
            var sliceDefault, sliceShow;
        
            [sliceShow, sliceDefault] = updateSliceShow();
        
            $(window).on("resize", function () {
            [sliceShow, sliceDefault] = updateSliceShow();
        
            load_more(".trtr_services_details", ".service", ".trtr_service_btn" ,"#trtr_service_more", sliceDefault, sliceShow);
            });
        
            load_more(".trtr_services_details", ".service", ".trtr_service_btn" ,"#trtr_service_more", sliceDefault, sliceShow);
        });
    </script>
    <!-- JS End -->
</body>
    </html>

