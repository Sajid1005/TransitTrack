<html>
	<head>
		<title>Add Product</title>
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
		<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
		<link href="https://fonts.googleapis.com/css2?family=Catamaran:wght@400;500;600;700;800&display=swap" rel="stylesheet">
		<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">

	</head>

	<body>
		<?php
			if ($_SERVER['REQUEST_METHOD'] === 'POST') {
				$Bus = $_POST["Bus"]; 
				$product_price = $_POST["product_price"];
				$target_dir = "uploads/";
				$target_file = $target_dir . basename($_FILES["product_file"]["name"]);
				move_uploaded_file($_FILES["product_file"]["tmp_name"], $target_file);

				$db =  mysqli_connect("127.0.0.1", "root" , "", "sajid");
			
					if ($db->connect_error) {
						echo "Something wrong with datababse connection";
					} 
					$x = "INSERT INTO product (Bus, product_price , product_image) VALUES ('$Bus', '$product_price', '$target_file')";
					$db->query($x);
					$_SESSION['success'] = "Prduct Added Successfully";
					header("Location:Add_product.php"); 
			}
		?>
		<div class="Blog_section">
			<?php
				include "Options.php";
			?>
			<div class="container">		
				<div class="row">
					<div class="col-md-8 offset-2">	
						<?php if(isset($_SESSION['success'])) {?>
						<p class="alert alert-primary"  ><?php echo $_SESSION['success']; ?></p>
						<?php unset($_SESSION['success']); } ?>
						<div class="card bg-dark">
							<div class="card-body">
								Add Product
							</div>
							<div class="card-body">	
								<form method="POST" action="Add_product.php" enctype="multipart/form-data">
									<div class="form-group">
					    				<label for="exampleFormControlFile1">Enter Product Title</label>
					    				<input name="Bus" type="text" class="form-control-file" id="exampleFormControlFile1" style="color:black;" required>
					  				</div>
									<div class="form-group">
					    				<label for="exampleFormControlFile1">Enter Product Price</label>
					    				<input name="product_price" type="number" class="form-control-file" id="exampleFormControlFile1" style="color:black;" required>
					  				</div>
					  				<div class="form-group">
					    				<label for="exampleFormControlFile1">Product Image</label>
					    				<input  name="product_file" type="file" class="form-control-file" id="exampleFormControlFile1" style="color:black;" required  accept="image/x-png,image/gif,image/jpeg">
					  				</div>
					  				<div class="form-group"><button class="btn btn-sm btn-primary">Save Product</button></div>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<script src="https://cdn.jsdelivr.net/npm/jquery@3.5.1/dist/jquery.slim.min.js"></script>
		<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
	</body>
</html>



