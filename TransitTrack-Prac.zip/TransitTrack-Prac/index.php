
<!DOCTYPE html>
<html lang="en">
<head>
    <!-- Deafult Meta Tag -->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- Title -->
    <title>TransitTrack | Home</title>
    <!-- Favicon -->
    <link rel="icon" id="favicon" href="./assets/images/favicon.png" type="image/gif" sizes="16x16">
    <!-- Google Font Link -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Barlow:wght@400;500;600;700&display=swap" rel="stylesheet">
    <!-- Font Awesome 5 CDN/ Icon Link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <!-- Slider CSS Link -->
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick.css">
    <link rel="stylesheet" href="./lib/slick-1.8.1/slick/slick-theme.css">
    <!-- Bootstarp 5 CSS -->
    <link rel="stylesheet" href="./lib/bootstrap-5/css/bootstrap.min.css">
    <!-- Main CSS -->
    <link rel="stylesheet" href="./assets/css/style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="./assets/css/responsive.css">
</head>
<body>
    <!-- Home Page Start -->

    <!--  Preloader Start  -->

    <!-- Header Start -->
    <?php
        include "./option.php";
    ?>
    <!-- Header End -->

    <!-- Hero Section Start -->
    <section class="trtr_hero_wrapper">
        <div class="container">
            <div class="trtr_hero_details text-center">
                <h1>Your Gateway To Seamless Bus Journeys</h1>
                <p>Sodales ante facilisis natoques eros quisque suspendisse. Pretium sed sit habitasse cras ium fermentum. Dui semper mi gravida hac vel imperdiet luctus diam tempu.</p>
                <a href="#" class="btn">See Bus Location</a>
            </div>
        </div>
    </section>
    <!-- Hero Section End -->

    <!-- About Section Start -->
    <section class="trtr_about_wrapper">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-md-6 mb-5 mb-md-0">
                    <div class="trtr_about_img_wrapper position-relative">
                        <div class="trtr_img_wrapper">
                            <img src="./assets/images/about_img_one.jpg" class="w-100 h-100" alt="About Image">
                        </div>
                        <div class="trtr_img_wrapper">
                            <img src="./assets/images/about_img_two.jpg" class="w-100 h-100" alt="About Image">
                        </div>
                        <div class="trtr_family_box text-center">
                            <h4>95+ Family</h4>
                            <p class="mb-0">Happily Satisfied</p>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 pt-5">
                    <h6>About us</h6>
                    <h2>We invite guests to celebrate and enjoy a life of luxury</h2>
                    <p>TransitTrack is a top-class, modern and attention-grabbing in the luxury bus service website template for your boutique accommodation business. If you are ready to bring your bus service services online</p>
                    <a href="./pages/about_us.php" class="btn">About us</a>
                </div>
            </div>
        </div>
    </section>
    <!-- About Section End -->

    <!-- Counter Section Start -->
    <section class="trtr_counter_wrapper">
        <div class="trtr_overlay">
            <div class="container">
                <div class="row">
                    <div class="col-6 col-lg-3 text-center mb-4 mb-lg-0">
                        <div class="trtr_counter">
                            <h1><span class="count">25</span>K+</h1>
                            <p class="mb-0">Happy clients</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 text-center">
                        <div class="trtr_counter trtr_border">
                            <h1><span class="count">174</span>+</h1>
                            <p class="mb-0">Our Checker</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 text-center">
                        <div class="trtr_counter">
                            <h1><span class="count">50</span>+</h1>
                            <p class="mb-0">Type of services</p>
                        </div>
                    </div>
                    <div class="col-6 col-lg-3 text-center">
                        <div class="trtr_counter border-0">
                            <h1><span class="count">10</span> +</h1>
                            <p class="mb-0">Our Route</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Counter Section End -->

    <!-- Services Section Start -->
    <section class="trtr_services_wrapper">
        <div class="container">
            <div class="row">
                <div class="col-lg-8 offset-lg-2 text-center">
                    <h6>why choose us</h6>
                    <h2>we provide our best service</h2>
                    <p class="trtr_title_content">Discover a range of meticulously crafted Our Checker that blend comfort and style. Each space is thoughtfully designed to offer a unique ambiance, ensuring a relaxing</p>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">01</div>
                        <h4>Safety Inspections</h4>
                        <p>Sweep your loved one off their feet with a romantic retreat by the sea. Relax in a beautifully appointed oceanview suite, where champagne and chocolate.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">02</div>
                        <h4>Regulatory Compliance</h4>
                        <p>Fuel your body with nutritious meals and detoxifying juices, and take home a complimentary wellness gift basket. Daily yoga classes, meditation.</p>
                    </div>
                </div>
                <div class="col-md-6 col-lg-4 service mb-5">
                    <div class="trtr_services_card position-relative">
                        <div class="trtr_icon_wrapper">
                            <i class="fas fa-car-alt"></i>
                        </div>
                        <div class="trtr_services_number">03</div>
                        <h4>Documentation Review</h4>
                        <p>Embark on an adrenaline-fueled adventure by the ocean with our Adventure Package. Choose from a variety of thrilling activities,</p>
                    </div>
                </div>
            </div>
            <div class="text-center">
                <a href="./pages/service.php" class="btn">View more</a>
            </div>
        </div>
    </section>
    <!-- Services Section End -->

    <!-- Gallery Section Start -->
    <section class="trtr_gallery_wrapper">
        <div class="container">
            <h6 class="text-center">Gallery</h6>
            <h2 class="text-center">A Visual Journey through TransitTrack</h2>
            <p class="trtr_title_content text-center">Immerse yourself in the beauty of TransitTrack through our captivating gallery</p>

            <div class="d-flex justify-content-center">
                <ul class="nav" id="pills-tab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="first-tab" data-bs-toggle="pill" data-bs-target="#first" type="button" role="tab" aria-controls="first" aria-selected="true">Our Checker</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="second-tab" data-bs-toggle="pill" data-bs-target="#second" type="button" role="tab" aria-controls="second" aria-selected="false">Local Bus</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="third-tab" data-bs-toggle="pill" data-bs-target="#third" type="button" role="tab" aria-controls="third" aria-selected="false">Highway Bus</button>
                    </li>
                </ul>
            </div>
    
            <div class="tab-content" id="tabContent">
                <div class="tab-pane fade show active" id="first" role="tabpanel" aria-labelledby="first-tab">
                    <div class="grid-container">
                        <div class="item_one gallery">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_five.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_two gallery">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_six.jpg" class="w-100 h-100" alt="Gallery Image">
                               
                            </div>
                        </div>
                        <div class="item_three gallery">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_seven.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_four gallery">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_four.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_five gallery">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_eight.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_six gallery">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_nine.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_seven gallery">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_two.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_eight gallery">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_three.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                    </div>
                   
                </div>


                <div class="tab-pane fade" id="second" role="tabpanel" aria-labelledby="second-tab">
                    <div class="grid-container">
                        <div class="item_one">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_five.jpg" class="w-100 h-100" alt="Gallery Image">
                            
                            </div>
                        </div>
                        <div class="item_two">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_six.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_three">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_seven.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_four">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_four.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_five">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_eight.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_six">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_nine.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_seven">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_two.jpg" class="w-100 h-100" alt="Gallery Image">
                               
                            </div>
                        </div>
                        <div class="item_eight">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_three.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="third" role="tabpanel" aria-labelledby="third-tab">
                    <div class="grid-container">
                        <div class="item_one">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_five.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_two">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_six.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_three">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_seven.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_four">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_four.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_five">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_eight.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_six">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_nine.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_seven">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_two.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_eight">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_three.jpg" class="w-100 h-100" alt="Gallery Image">
                               
                            </div>
                        </div>
                    </div>
                </div>
                <div class="tab-pane fade" id="fourth" role="tabpanel" aria-labelledby="fourth-tab">
                    <div class="grid-container">
                        <div class="item_one">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_five.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_two">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_six.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_three">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_seven.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_four">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_four.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_five">
                            <div class="trtr_img_wrapper trtr_large_img position-relative">
                                <img src="./assets/images/gallery_img_eight.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_six">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_nine.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_seven">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_two.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                        <div class="item_eight">
                            <div class="trtr_img_wrapper position-relative">
                                <img src="./assets/images/gallery_img_three.jpg" class="w-100 h-100" alt="Gallery Image">
                                
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Gallery Section End -->


    <!-- Footer Section Start -->
    <footer class="trtr_footer_wrapper">
        <div class="trtr_overlay">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-xl-3 mb-4 mb-md-0">
                        <a href="./index.php"><img src="./assets/images/footer_logo.svg" alt="Footer Logo"></a>
                        <p>It is a long established fact that a reader will be distracted lookings.</p>
                        <ul class="list-group list-group-horizontal trtr_social_media">
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-facebook-f"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                            </li>
                            <li>
                                <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
                            </li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-xl-3">
                        <div class="trtr_page_link">
                            <h5>Useful Links</h5>
                            <ul class="trtr_useful_link">
                                <li>
                                    <a href="./pages/about_us.php">About Us</a>
                                </li>
                                <li>
                                    <a href="./pages/service.php">Service</a>
                                </li>
                                <li>
                                    <a href="./pages/gallery.php">Gallery</a>
                                </li>
                               
                                <li>
                                    <a href="./pages/contactus.php">Contact Us</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    
                    <div class="col-md-6 col-xl-3">
                        <h5>Contact</h5>
                        <ul class="trtr_footer_contact">
                            <li>
                                <a href="tel:+13866883295" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-phone-alt"></i>
                                        </div>
                                    </div>
                                    +1 386-688-3295
                                </a>
                            </li>
                            <li>
                                <a href="mailto:contact@TransitTrack.com" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-envelope"></i>
                                        </div>
                                    </div>
                                    contact@TransitTrack.com
                                </a>
                            </li>
                            <li>
                                <a href="https://www.google.com/maps/place/GXF4%2B8HQ,+Chippenham,+UK/@51.5233408,-2.0460905,17z/data=!3m1!4b1!4m5!3m4!1s0x4871630088ddd45d:0x560ecf1533aac5e1!8m2!3d51.5233375!4d-2.0435156?entry=ttu" target="_blank" class="d-flex align-items-center">
                                    <div>
                                        <div class="trtr_icon_box">
                                            <i class="fas fa-map-marker-alt"></i>
                                        </div>
                                    </div>
                                    GXF4+8HQ Chippenham United Kingdom
                                </a>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="trtr_copy_right">
                    <div class="row align-items-center">
                        <div class="col-md-6 text-center text-md-start mb-2 mb-md-0">
                            <p class="mb-0">Copyright &copy; <a href="#" target="_blank">TransitTrack</a>. All Right Reserved</p>
                        </div>
                        <div class="col-md-6 d-flex justify-content-center justify-content-md-end">
                            <a href="#" target="_blank">Terms & Conditions</a>
                            <a href="#" target="_blank" class="ps-4">Privacy Policy</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <!-- Footer Section End -->
    
    <!-- Scroll Button Start -->
    <div id="scrollBtn" class="trtr_scroll_btn">
        <a href="#">
            <i class="fas fa-chevron-up"></i>
        </a>
    </div>
    <!-- Scroll Button  End -->
    <!-- Home Page End -->
    
    

    <!-- JS CDN -->
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <!-- Bootstrap 5 JS -->
    <script src="./lib/bootstrap-5/js/bootstrap.bundle.min.js"></script>
    <!-- Slider JS Link -->
    <script src="./lib/slick-1.8.1/slick/slick.min.js"></script>
    <!-- Main JS Link -->
    <script src="./assets/js/main.js"></script>
</body>
</html>